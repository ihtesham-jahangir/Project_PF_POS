#include<iostream>
#include <string>
#include <conio.h>
using namespace std;

void s_menu(void){
	cout<<"===Shop menu==="<<endl;
	cout<<"code [673]cheese sticks         PKR. 400rs"<<endl;
	cout<<"code [674]oven baked wings      PKR. 280rs"<<endl;
	cout<<"code [675]flaming wings         PKR. 300rs"<<endl;
	cout<<"code [676]calzone wings         PKR. 690rs"<<endl;
	cout<<"code [677]arabic rolls          PKR. 350rs"<<endl;
}

int  main()
{ 
	int a_roll=0 , o_baked=0 , c_stick=0 ,c_wings=0,f_wings=0, t_charge=0;
	string u_name;
	string pass;
	int c_amount,o_amount,f_amount,ca_amount,a_amount;
	int c_total=0,o_total=0,f_total=0,ca_total=0,a_total=0;
	cout<<"\t\t\t=========================="<<endl;
	cout<<"\t\t\t    Rich Burger's  Shop"<<endl;
	cout<<"\t\t\t==========================\n\n"<<endl;
	cout<<"\t\t   Administrator Enter Your Credentials \n"<<endl;
	cout<<"Admin Username :  "<<endl;
	cin>>u_name;
	cout<<"Admin Password : "<<endl;
	cin>>pass;
	if (u_name == "admin123"  && pass=="pass123" )
	{
		//starter Package
	int n;
	while(true){
s_menu();
	cin>>n;
		switch (n){
	case 673:{
		 
		cout<<"Quantity : \n";
		cin>>c_amount;
		c_stick=c_stick+400;
		c_total=(c_stick * c_amount);
		cout<<"Total Amount of Cheese Sticks : \n"<<c_total;
			 }break;
	case 674:{
			 
		cout<<"Quantity : \n";
		cin>>o_amount;
		o_baked=o_baked+280;
		o_total=(o_baked * o_amount);
		cout<<"Total Amount of Cheese Sticks : \n"<<o_total;
			 }break;
	case 675:{
	   	 
		cout<<"Quantity  : \n";
		cin>>f_amount;
		f_wings=f_wings+300;
		f_total=(f_wings * f_amount);
		cout<<"Total Amount of Cheese Sticks : \n"<<f_total;
			 } break;
			 case 676:{
		
		cout<<"Quantity  : \n";
		cin>>ca_amount;
		c_wings=c_wings+690;
		ca_total=(c_wings * ca_amount);
		cout<<"Total Amount of Cheese Sticks : \n"<<ca_total;
			 }
		 break;
	case 677:{	 
		cout<<"Quantity  : \n";
		cin>>a_amount;
		a_roll=a_roll+350;
		a_total=(a_roll * a_amount);
		cout<<"Total Amount of Cheese Sticks : \n"<<a_total;
			 }
			 break;
		}
		char count;
		cout<<"\n Do You Want To Get More : (Y/N) : "<<endl;
		cin>>count;

		if(count!='y' && count!='Y')
			break;
		}
		
	}
	else{
		cout<<"else Enterence"<<endl;
	}

	t_charge = a_total+ca_total+o_total+f_total+c_total;
	cout<<"Total Amount =  "<<t_charge;
	cout<<"\nThank You For Visiting Rich's Burger Shop \n";
	return 0;

}